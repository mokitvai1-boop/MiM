# Telegram AI Bot — Render Docker deployment

## Features
- Telegram long polling for incoming text messages.
- Sends questions to the configured AI endpoint.
- Shows a temporary “Thinking...” reply and edits it with the answer when possible.
- Handles API/network errors with a Bengali fallback message.
- Retries polling after unexpected errors.

## Security first
The bot token previously pasted in chat should be treated as exposed. Revoke it using
Telegram `@BotFather` and create a new token. Add the new token only in Render's
Environment settings. Do not commit tokens to GitHub or include them in ZIP files.

## Deploy
1. Upload the files in this folder to a GitHub repository.
2. In Render, create a new service from the repository and use the Docker runtime.
3. Add these Environment Variables in Render:
   - `TELEGRAM_BOT_TOKEN` = your newly generated token
   - `AI_API_URL` = `https://fariha-x-tynx.vercel.app/gem`
   - `AI_API_TIMEOUT` = `45` (optional)
4. Deploy and inspect logs for `Starting Telegram bot polling`.
5. Open Telegram and send `/start`, then send a test question.

## Always-on notes
- Choose a paid always-on service if you need to avoid free-tier sleeping. Availability and
  restart behavior depend on Render's current plan and platform policies.
- Run only one active polling instance for a given bot token. Multiple instances can cause
  Telegram polling conflicts.
- This project uses long polling and does not require a web port.
- A successful deploy does not guarantee that the external AI endpoint is healthy or that
  its response format is compatible. The endpoint should return JSON containing `reply`,
  `response`, `text`, or `answer`, or plain text.
