import html
import logging
import os
import time
from urllib.parse import urlparse

import requests
import telebot

logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
AI_API_URL = os.getenv("AI_API_URL", "https://fariha-x-tynx.vercel.app/gem").strip()
REQUEST_TIMEOUT = int(os.getenv("AI_API_TIMEOUT", "45"))

if not TOKEN:
    raise RuntimeError(
        "TELEGRAM_BOT_TOKEN is missing. Set it in Render > Environment."
    )
if not AI_API_URL.startswith(("https://", "http://")):
    raise RuntimeError("AI_API_URL must be an http:// or https:// URL.")

bot = telebot.TeleBot(TOKEN, parse_mode=None)


def ask_ai(question: str) -> str:
    response = requests.get(
        AI_API_URL,
        params={"text": question},
        timeout=REQUEST_TIMEOUT,
        headers={"Accept": "application/json, text/plain"},
    )
    response.raise_for_status()

    try:
        payload = response.json()
        if isinstance(payload, dict):
            for key in ("reply", "response", "text", "answer"):
                value = payload.get(key)
                if value:
                    return str(value).strip()
    except ValueError:
        pass

    return response.text.strip()


@bot.message_handler(commands=["start", "help"])
def start(message):
    bot.reply_to(
        message,
        "👋 স্বাগতম! আমাকে যেকোনো প্রশ্ন লিখে পাঠান। আমি উত্তর দেওয়ার চেষ্টা করব।",
    )


@bot.message_handler(content_types=["text"])
def handle_text(message):
    question = (message.text or "").strip()
    if not question or question.startswith("/"):
        return

    waiting = None
    try:
        waiting = bot.reply_to(message, "💭 Thinking...")
        answer = ask_ai(question)
        if not answer:
            answer = "⚠️ দুঃখিত, এখন কোনো উত্তর পাওয়া যায়নি। পরে আবার চেষ্টা করুন।"

        # Telegram allows up to 4096 characters per text message.
        answer = answer[:4000]
        try:
            bot.edit_message_text(
                answer,
                chat_id=message.chat.id,
                message_id=waiting.message_id,
            )
        except Exception:
            # If editing fails, send the answer as a new message.
            bot.reply_to(message, answer)

    except requests.RequestException:
        logger.exception("AI API request failed")
        notice = "⚠️ AI সার্ভারে এখন সংযোগ করা যাচ্ছে না। কিছুক্ষণ পরে আবার চেষ্টা করুন।"
        try:
            if waiting:
                bot.edit_message_text(
                    notice,
                    chat_id=message.chat.id,
                    message_id=waiting.message_id,
                )
            else:
                bot.reply_to(message, notice)
        except Exception:
            logger.exception("Could not send API error message")

    except Exception:
        logger.exception("Failed to process Telegram message")
        try:
            bot.reply_to(message, "❌ একটি সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।")
        except Exception:
            logger.exception("Could not send fallback error message")


if __name__ == "__main__":
    logger.info("Starting Telegram bot polling")
    # One Render instance should run this polling bot for this token.
    # Render restarts the service after process exits, subject to platform limits.
    while True:
        try:
            bot.infinity_polling(
                skip_pending=True,
                timeout=30,
                long_polling_timeout=30,
            )
        except Exception:
            logger.exception("Polling stopped unexpectedly; retrying shortly")
            time.sleep(5)
